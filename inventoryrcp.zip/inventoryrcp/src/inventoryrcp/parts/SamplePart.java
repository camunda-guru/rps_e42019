package inventoryrcp.parts;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.eclipse.core.databinding.observable.value.IObservableValue;
import org.eclipse.e4.ui.di.Focus;
import org.eclipse.e4.ui.di.Persist;
import org.eclipse.e4.ui.model.application.ui.MDirtyable;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecp.ui.view.ECPRendererException;
import org.eclipse.emf.ecp.ui.view.swt.ECPSWTView;
import org.eclipse.emf.ecp.ui.view.swt.ECPSWTViewRenderer;
import org.eclipse.emf.ecp.view.spi.context.ViewModelContext;
import org.eclipse.emf.ecp.view.spi.context.ViewModelContextFactory;
import org.eclipse.emf.ecp.view.spi.model.VElement;
import org.eclipse.emf.ecp.view.spi.provider.ViewProviderHelper;
import org.eclipse.jface.databinding.swt.SWTObservables;
import org.eclipse.jface.databinding.viewers.ViewersObservables;
import org.eclipse.jface.layout.GridDataFactory;
import org.eclipse.jface.layout.GridLayoutFactory;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Text;

import models.BaseObject;
import models.Category;
import models.ModelsFactory;
import models.ModelsPackage;
import models.Product;

public class SamplePart {

	private Text txtInput;
	private TableViewer tableViewer;

	@Inject
	private MDirtyable dirty;

	/*private EObject getDummyEObject() {
		ModelsFactory factory=ModelsFactory.eINSTANCE;
		Category category =factory.createCategory();
		category.setCategoryId(395769);
		category.setName("Garments");
		
		Product product=factory.createProduct();
		product.setProductId(436587);
		product.setName("Shirt");
		product.setDop(new Date(119,3,3));
        final EClass eClass =factory.getModelsPackage().getProduct();
        return EcoreUtil.create(eClass);
    }*/
	@PostConstruct
	public void createComposite(Composite parent) {
		parent.setLayout(new GridLayout(1, false));
		
		//ViewModelContext viewModelContext = ViewModelContextFactory.INSTANCE.createViewModelContext(ViewProviderHelper.getView(eObject, null), eObject, new DefaultReferenceService());
		//model = EcoreUtil.create(ModelsFactory.eINSTANCE.getModelsPackage());
		/*try {
			ECPSWTViewRenderer.INSTANCE.render(parent, product);
			} catch (ECPRendererException e1) {
			e1.printStackTrace();
			}*/
		//final EObject dummyObject = getDummyEObject();
        try {
        	ModelsFactory factory=ModelsFactory.eINSTANCE;
        	//BaseObject object = factory.createBaseObject();
    		Category category =factory.createCategory();
    		category.setCategoryId(395769);
    		category.setName("Garments");
    		
    		Product product=factory.createProduct();
    		product.setProductId(436587);
    		product.setName("Shirt");
    		product.setDop(new Date(119,3,3));
            final Composite content = new Composite(parent, SWT.NONE);
            content.setBackground(parent.getDisplay().getSystemColor(SWT.COLOR_WHITE));
            content.setLayout(GridLayoutFactory.fillDefaults().margins(10, 10).create());
            content.setLayoutData(GridDataFactory.fillDefaults().create());
            ECPSWTView view = ECPSWTViewRenderer.INSTANCE.render(content, product);
            content.layout();
            PropertyChangeListener l = new PropertyChangeListener() {
                public void propertyChange(PropertyChangeEvent evt) {
                    
                    System.out.println(((Number)evt.getOldValue()).intValue());
                    
                }
            };
         
           //
           //object.setAddPropertyChangeListener(l);
            
          

            
        } catch (final ECPRendererException e) {
            e.printStackTrace();
        }
        parent.layout();

		/*txtInput = new Text(parent, SWT.BORDER);
		txtInput.setMessage("Enter text to mark part as dirty");
		txtInput.addModifyListener(new ModifyListener() {
			@Override
			public void modifyText(ModifyEvent e) {
				dirty.setDirty(true);
			}
		});
		txtInput.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

		tableViewer = new TableViewer(parent);

		tableViewer.setContentProvider(ArrayContentProvider.getInstance());;
		tableViewer.setInput(createInitialDataModel());
		tableViewer.getTable().setLayoutData(new GridData(GridData.FILL_BOTH));*/
	}

	/*@Focus
	public void setFocus() {
		tableViewer.getTable().setFocus();
	}*/

	@Persist
	public void save() {
		dirty.setDirty(false);
	}
	
	private List<String> createInitialDataModel() {
		return Arrays.asList("Sample item 1", "Sample item 2", "Sample item 3", "Sample item 4", "Sample item 5");
	}
}