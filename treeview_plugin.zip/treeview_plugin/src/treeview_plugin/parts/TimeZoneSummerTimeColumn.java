
package treeview_plugin.parts;

import java.time.Instant;
import java.time.ZoneId;

import org.eclipse.swt.SWT;

public class TimeZoneSummerTimeColumn extends BookColumn {
	public String getText(Object element) {
		if (element instanceof ZoneId) {
			return String.valueOf(!((ZoneId) element).getRules().getDaylightSavings(Instant.now()).isZero());
		} else {
			return "";
		}
	}

	public String getTitle() {
		return "Summer Time";
	}

	public int getWidth() {
		return 100;
	}

	public int getAlignment() {
		return SWT.RIGHT;
	}
}