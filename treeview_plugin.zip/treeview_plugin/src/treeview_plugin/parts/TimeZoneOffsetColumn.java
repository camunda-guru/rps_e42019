package treeview_plugin.parts;

import java.time.Instant;
import java.time.ZoneId;

import org.eclipse.swt.SWT;

public class TimeZoneOffsetColumn extends BookColumn {
	public String getText(Object element) {
		if (element instanceof ZoneId) {
			return ((ZoneId) element).getRules().getOffset(Instant.now()).toString();
		} else {
			return "";
		}
	}

	public String getTitle() {
		return "Offset";
	}

	public int getWidth() {
		return 50;
	}
	
	public int getAlignment() {
		return SWT.RIGHT;
	}
}