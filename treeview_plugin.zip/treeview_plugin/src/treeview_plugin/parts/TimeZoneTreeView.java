package treeview_plugin.parts;

import java.net.URL;
import java.time.ZoneId;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;
import org.eclipse.e4.core.di.annotations.Optional;
import org.eclipse.e4.ui.di.Focus;
import org.eclipse.e4.ui.services.IServiceConstants;
import org.eclipse.e4.ui.workbench.modeling.ESelectionService;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.resource.FontRegistry;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.jface.resource.LocalResourceManager;
import org.eclipse.jface.resource.ResourceManager;
import org.eclipse.jface.viewers.DelegatingStyledCellLabelProvider;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerFilter;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.ISharedImages;

public class TimeZoneTreeView {
	//private Label myLabelInView;
	private TreeViewer treeViewer;

	@Inject
	private ISharedImages images;
	@Inject
	@Optional
	private ESelectionService selectionService;
	@PostConstruct
	public void createPartControl(Composite parent) {
		System.out.println("Enter in SampleE4View postConstruct");

		ResourceManager rm = JFaceResources.getResources();
		LocalResourceManager lrm = new LocalResourceManager(rm, parent);
		ImageRegistry ir = new ImageRegistry(lrm);
		URL sample = getClass().getResource("/icons/Sample.png");
		ir.put("sample", ImageDescriptor.createFromURL(sample));
		treeViewer = new TreeViewer(parent, SWT.H_SCROLL | SWT.V_SCROLL | SWT.MULTI);
		FontRegistry fr = JFaceResources.getFontRegistry();
		treeViewer.setLabelProvider(new TimeZoneLabelProvider(images, ir,fr));
		treeViewer.setContentProvider(new TimeZoneContentProvider());
		treeViewer.setComparator(new TimeZoneViewerComparator());
		//treeViewer.setFilters(new ViewerFilter[] {
			//	new TimeZoneViewerFilter("GMT")});
		//treeViewer.setExpandPreCheckFilters(true);
		treeViewer.setInput(new Object[] { TimeZoneComparator.getTimeZones() });
		treeViewer.addDoubleClickListener(event -> {
			Viewer viewer = event.getViewer();
			Shell shell = viewer.getControl().getShell();
			ISelection sel = viewer.getSelection();
			Object selectedValue;
			if (!(sel instanceof IStructuredSelection) || sel.isEmpty()) {
			selectedValue = null;
			} else {
			selectedValue = ((IStructuredSelection)sel).getFirstElement();
			}
			if (selectedValue instanceof ZoneId) {
			ZoneId timeZone = (ZoneId)selectedValue;
			MessageDialog.openInformation(shell, timeZone.getId(),
			timeZone.toString());
			}
			});
		treeViewer.addSelectionChangedListener(event -> {
			// forward selection
			Object selection =
			((IStructuredSelection)event.getSelection()).
			getFirstElement();
			if (selection != null && selectionService != null) {
			selectionService.setSelection(selection);
			}
			});
	}

	@Focus
	public void setFocus() {
		treeViewer.getControl().setFocus();


	}

	/**
	 * This method is kept for E3 compatiblity. You can remove it if you do not
	 * mix E3 and E4 code. <br/>
	 * With E4 code you will set directly the selection in ESelectionService and
	 * you do not receive a ISelection
	 * 
	 * @param s
	 *            the selection received from JFace (E3 mode)
	 */
	/*@Inject
	@Optional
	public void setSelection(@Named(IServiceConstants.ACTIVE_SELECTION) ISelection s) {
		if (s.isEmpty())
			return;

		if (s instanceof IStructuredSelection) {
			IStructuredSelection iss = (IStructuredSelection) s;
			if (iss.size() == 1)
				setSelection(iss.getFirstElement());
			else
				setSelection(iss.toArray());
		}
	}

	*//**
	 * This method manages the selection of your current object. In this example
	 * we listen to a single Object (even the ISelection already captured in E3
	 * mode). <br/>
	 * You should change the parameter type of your received Object to manage
	 * your specific selection
	 * 
	 * @param o
	 *            : the current object received
	 *//*
	@Inject
	@Optional
	public void setSelection(@Named(IServiceConstants.ACTIVE_SELECTION) Object o) {

		// Remove the 2 following lines in pure E4 mode, keep them in mixed mode
		if (o instanceof ISelection) // Already captured
			return;

		// Test if label exists (inject methods are called before PostConstruct)
		if (myLabelInView != null)
			myLabelInView.setText("Current single selection class is : " + o.getClass());
	}

	*//**
	 * This method manages the multiple selection of your current objects. <br/>
	 * You should change the parameter type of your array of Objects to manage
	 * your specific selection
	 * 
	 * @param o
	 *            : the current array of objects received in case of multiple selection
	 *//*
	@Inject
	@Optional
	public void setSelection(@Named(IServiceConstants.ACTIVE_SELECTION) Object[] selectedObjects) {

		// Test if label exists (inject methods are called before PostConstruct)
		if (myLabelInView != null)
			myLabelInView.setText("This is a multiple selection of " + selectedObjects.length + " objects");
	}*/
}
