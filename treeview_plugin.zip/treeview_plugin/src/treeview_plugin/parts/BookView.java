package treeview_plugin.parts;

import java.time.ZoneId;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;

import org.eclipse.e4.core.di.annotations.Optional;
import org.eclipse.e4.ui.di.Focus;
import org.eclipse.e4.ui.services.IServiceConstants;
import org.eclipse.e4.ui.workbench.modeling.ESelectionService;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;

public class BookView {
	private TableViewer tableViewer;
	private ZoneId timeZone;
	@Inject
	@Optional
	public void setTimeZone(
	@Named(IServiceConstants.ACTIVE_SELECTION) ZoneId timeZone) {
	}
	@PostConstruct
	public void createPartControl(Composite parent) {
		System.out.println("Enter in SampleE4View postConstruct");
		tableViewer = new TableViewer(parent, SWT.H_SCROLL |
				SWT.V_SCROLL);
		tableViewer.getTable().setHeaderVisible(true);
		tableViewer.setContentProvider(ArrayContentProvider.getInstance());
		new TimeZoneIDColumn().addColumnTo(tableViewer);
		new TimeZoneDisplayNameColumn().addColumnTo(tableViewer);
		new TimeZoneOffsetColumn().addColumnTo(tableViewer);
		new TimeZoneSummerTimeColumn().addColumnTo(tableViewer);

				tableViewer.setContentProvider(
				ArrayContentProvider.getInstance());
				
				tableViewer.setInput(ZoneId.getAvailableZoneIds().stream().map(ZoneId::of).toArray());
				if (timeZone != null && tableViewer != null) {
					tableViewer.setSelection(new StructuredSelection(timeZone));
					tableViewer.reveal(timeZone);
					}
	}

	@Focus
	public void setFocus() {
		tableViewer.getControl().setFocus();

	}

	
}
