package treeview_plugin.parts;

import java.time.ZoneId;
import java.time.format.TextStyle;
import java.util.Locale;

public class TimeZoneDisplayNameColumn extends BookColumn {
	public String getText(Object element) {
		if (element instanceof ZoneId) {
			return ((ZoneId) element).getDisplayName(TextStyle.FULL, Locale.getDefault());
		} else {
			return "";
		}
	}

	public String getTitle() {
		return "Display Name";
	}
}